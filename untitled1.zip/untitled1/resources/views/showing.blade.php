<html>
<body>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
<div class="col-md-auto">
<div class="container">
    <section>

    <div class="card-columns" style="width:auto;">
        @for($i=0 ; $i<count($title) ; $i++)
            <br>

            <div class="row">
                <div class="card" style="width:auto; margin-top: 20px; margin-left:20px; margin-right: 20px; text-align: center;">
                    <img class="card-img-top" src="{{ $img[$i] }}" alt="Card image cap">
                    <div class="card-block">
                        <h4 class="card-title">{{ $title[$i] }}</h4>
                        <p class="card-text">{{ $content[$i] }}</p>
                        <p class="card-text"><small class="text-muted"><a href=" {{ $link[$i] }}">لینک مربوطه</a><br></small><br></p>
                    </div>
                </div>
            </div>

            <br>

        @endfor
        </div>
    </section>

</div>
</div>
</body>


</html>



