<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['namespace' => 'API'], function () {


    Route::post('login', 'UserController@login');

    Route::post('register', 'UserController@register');



});





Route::group(['middleware' => 'auth:api', 'namespace' => 'API'], function(){


    Route::post('get-details', 'UserController@get_details');

    Route::post('/Insert_Order','CoffeeController@Insert_Order');

    Route::post('/Insert_Product','CoffeeController@Insert_Product');

    Route::get('/All_Product','CoffeeController@All_Product');

    Route::get('/All_Order','CoffeeController@All_Order');

    Route::get('/My_orders/{id}','CoffeeController@My_orders');

    Route::post('/Change_Status_order/{customerId}','CoffeeController@Change_Status_order');

    Route::post('/Cancel_order/{customerId}','CoffeeController@Cancel_order');

});




