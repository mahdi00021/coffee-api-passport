<?php





Route::group(['middleware' => 'cachepage'], function ()
{


    Route::get('/', function () {
        return view('welcome');
    });

    Route::any('mahdi/{id}','ShowController@show');

});

Route::any('/index/{id}','ShowController@index');


