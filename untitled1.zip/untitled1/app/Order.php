<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'orders';

    protected $fillable = ['name_product','customerId','customer_name','status','price','type'];

    public $timestamps = false;
}
