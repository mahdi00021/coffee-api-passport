<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mymodel extends Model
{


}
