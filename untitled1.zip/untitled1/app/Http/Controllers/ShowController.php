<?php
/**
 * Created by PhpStorm.
 * User: MAHDI
 * Date: 17/02/2018
 * Time: 20:03
 */

namespace App\Http\Controllers;
use DateTime;

class ShowController extends Controller
{

    public function show($id)
    {


            $val['link']= ['http://ihnaa.ir','http://google.com','http://isna.ir','http://irna.ir','http://iran.ir','http://ilna.ir'];
            $val['title']=[$id.' '.'تیتر یک',$id.' '.'تیتر دوم',$id.' '.'تیتر سوم',$id.' '.'تیتر چهارم',$id.' '.'تیتر پنجم',$id.' '.'تیتر ششم'];
            $val['content']=['متن یک','متن دوم','متن سوم','متن چهارم','متن پنجم','متن ششم'];
            $val['img']=[asset('img/1.jpg'),asset('img/2.jpg'),asset('img/3.jpg'),asset('img/1.jpg'),asset('img/2.jpg'),asset('img/3.jpg')];



        //return $val;
           return view('showing',$val);



    }

    public function index($id)
    {
        $val['link']= ['http://ihnaa.ir','http://google.com','http://isna.ir','http://irna.ir','http://iran.ir','http://ilna.ir'];
        $val['title']=[$id.' '.'تیتر یک',$id.' '.'تیتر دوم',$id.' '.'تیتر سوم',$id.' '.'تیتر چهارم',$id.' '.'تیتر پنجم',$id.' '.'تیتر ششم'];
        $val['content']=['متن یک','متن دوم','متن سوم','متن چهارم','متن پنجم','متن ششم'];
        $val['img']=[asset('img/1.jpg'),asset('img/2.jpg'),asset('img/3.jpg'),asset('img/1.jpg'),asset('img/2.jpg'),asset('img/3.jpg')];


        return view('showing',$val);

    }

}