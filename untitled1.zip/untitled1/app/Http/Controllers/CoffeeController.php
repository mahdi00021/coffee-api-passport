<?php

namespace App\Http\Controllers;
use App\Order;
use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Response;


/**
 * @Note : In Controller if we don't have view , laravel return json format of Returns of Functions
 * @author : mahdi norouzi
 * @since : 2018 november 5
 * @api : json make by laravel Eloquent
 * Class CoffeeController
 * @package App\Http\Controllers
 * @uses : App\Products model
 * @uses : App\Orders model
 */

class CoffeeController extends Controller
{



    /**
     * @Note : This method is for Insert Order by customer
     * @param Request $request post http
     * @return string
     * @throws \Throwable
     */
    public function Insert_Order(Request $request)
    {

        $output = array();

        if($request != null) {

            $order = new Order;
            $order->name_product = $request->post('name');
            $order->customerId = $request->post('customerId');
            $order->customer_name = $request->post('customer_name');
            $order->status = $request->post('status');
            $order->price = $request->post('price');
            $order->type = $request->post('type');

            try {

                if ($order->save()) {

                    return $output['response'] = 'Success !';

                } else {

                    return $output['response'] = 'fail !';

                }

            } catch (\Throwable $e) {

                return $output['response'] = 'Throw erorr !';

            }

        }


    }




    /**
     * @Note This method is for Insert Product by admin if Login
     * @param Request $request post http
     * @return string
     * @throws \Throwable
    */
    public function Insert_Product(Request $request)
    {

        $output = array();

        if($request != null) {

                    $product = new Product;
                    $product->name = $request->post('name');
                    $product->options = $request->post('options');
                    $product->price = $request->post('price');
                    $product->type = $request->post('type');
                    $product->saveOrFail();

                    try {

                        if ($product->saveOrFail()) {

                            return $output['response'] = 'Success !';

                        } else {

                            return $output['response'] = 'fail !';

                        }

                    } catch (\Throwable $e) {

                        return $output['response'] = 'Throwable erorr !';

                    }


        }


    }





    /**
     * @Note This method return All Products of database
     * @return string
    */
    public function All_Product()
    {

        return Products::all()->toJson();

    }






    /**
     * @Note This method return All Orders of database
     *
     * @return string json format
    */
    public function All_Order()
    {

        return Orders::all()->toJson();

    }







    /**
     * @Note This method return order current user of database
     * @param $id
     * @return mixed
     */
    public function My_orders($id)
    {

        if($id != null) {

           return Orders::where("Customer","=",$id)->firstOrFail()->toJson();

        }

    }






    /**
     * @Note: This method will run by admin
     * @Note This method change order current request of database
     * @param $request post http
     * @param $customerId
     * @return string
     */
    public function Change_Status_order(Request $request,$customerId)
    {

        if($request && $customerId != null)
        {
            if(Auth::login()) {

                    $output = array();

                    $operation = Orders::where("Customer", "=", $customerId)->update(array('status' => $request->post('status')));

                    if ($operation) {

                        return $output['response'] = 'Success !';

                    } else {

                        return $output['response'] = 'fail !';

                    }

            } else{

                return $output['response'] = 'You are not login !';

            }
        }
    }






    /**
     * @Note This method Cancel_orders current request of database
     * @Note parameter $request for get order and Cancel_orders
     * @param $customerId
     * @return string
     */
    public function Cancel_order($customerId)
    {


        if($customerId != null)
        {

            $output = array();

            $operation = Orders::where("Customer", "=", $customerId)->update(array('status' => 'cancel'));

            if ($operation) {

               return $output['response'] = 'Successful canceled !';

            } else {

               return $output['response'] = 'fail cancel !';

            }

        }

    }

}