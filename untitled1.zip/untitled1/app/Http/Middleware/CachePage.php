<?php
/**
 * Created by PhpStorm.
 * User: MAHDI
 * Date: 20/02/2018
 * Time: 00:21
 */

namespace App\Http\Middleware;
use Closure;
use Cache;
use DateTime;

class CachePage
{

    public function handle($request, Closure $next)
    {
        $key = $request->fullUrl();  //key for caching/retrieving the response value


        if (Cache::has($key))  //If it's cached...

            return response(Cache::get($key))
                ->setLastModified(new DateTime("now"))
                ->setExpires(new DateTime("tomorrow"));


           // return response(Cache::get($key));   //... return the value from cache and we're done.

        $response = $next($request);  //If it wasn't cached, execute the request and grab the response

        $cachingTime = 60;  //Let's cache it for 60 minutes
        Cache::put($key, $response->getContent(), $cachingTime);  //Cache response

        return $response;
    }


}